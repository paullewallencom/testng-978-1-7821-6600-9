package main.java.org.test.mocking;

public interface Calculator {

	double multiply(double a, double b);

	double square(double a);

}