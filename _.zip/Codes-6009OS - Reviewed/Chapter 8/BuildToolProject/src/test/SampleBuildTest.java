package test;

import org.testng.annotations.Test;

public class SampleBuildTest {
	
	@Test
	public void testMethodOne(){
		System.out.println("Test method one executed");
	}
	
	@Test
	public void testMethodTwo(){
		System.out.println("Test method two executed");
	}
}
