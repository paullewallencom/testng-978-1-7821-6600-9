package test.sample;

import org.testng.annotations.Test;

public class SampleTest {
	@Test
	public void testMethodOne(){
		System.out.println("Test method One");
	}
	
	@Test
	public void testMethodTwo(){
		System.out.println("Test method two");
	}

}
