package test.classes;

import org.testng.annotations.Test;

public class SimpleTest {
	
	@Test
	public void simpleTest(){
		System.out.println("Simple Test Method.");
	}
	

}
