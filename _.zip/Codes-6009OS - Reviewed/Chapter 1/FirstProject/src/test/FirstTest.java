package test;

import org.testng.annotations.Test;

public class FirstTest {
  @Test
  public void testMethod() {
	  System.out.println("First TestNG test");
  }  
}
