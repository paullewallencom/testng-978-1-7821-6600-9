package test.secondpackage;

import org.testng.annotations.Test;

public class FirstTestClass {
	@Test
	public void firstTest(){
		System.out.println("First test method");
	}
	
	@Test
	public void secondTest(){
		System.out.println("Second test method");
	}

}
