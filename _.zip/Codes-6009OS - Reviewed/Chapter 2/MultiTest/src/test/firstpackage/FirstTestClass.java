package test.firstpackage;

import org.testng.annotations.Test;

public class FirstTestClass {
	@Test
	public void firstTest(){
		System.out.println("First test method");
	}

}
