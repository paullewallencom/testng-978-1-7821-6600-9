package test.firstpackage;

import org.testng.annotations.Test;

public class SecondTestClass {
	@Test
	public void secondTest(){
		System.out.println("Second test method");
	}


}
